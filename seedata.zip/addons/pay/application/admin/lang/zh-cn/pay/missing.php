<?php

return [
    'Id'         => 'ID',
    'Type'       => '类型',
    'Price'      => '订单价格',
    'Order_id'   => '关联订单号',
    'Wechat'     => '微信支付',
    'Alipay'     => '支付宝',
    'Settled'    => '已处理',
    'Unsettled'  => '未处理',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间',
];
