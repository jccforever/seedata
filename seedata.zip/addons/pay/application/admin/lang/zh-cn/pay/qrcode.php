<?php

return [
    'Product_id' => '产品',
    'Image'      => '收款二维码图片',
    'Realprice'  => '金额',
    'Url'        => '支付URL',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间',
    'Status'     => '状态'
];
