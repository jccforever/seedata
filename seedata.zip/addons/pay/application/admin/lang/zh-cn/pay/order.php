<?php

return [
    'Id'           => '订单号',
    'Product_id'   => '产品ID',
    'Qrcode_id'    => '二维码ID',
    'Price'        => '订单价格',
    'Realprice'    => '真实价格',
    'Title'        => '订单标题',
    'Out_order_id' => '外部订单号',
    'Extend'       => '自定义',
    'Paytype'      => '支付方式',
    'Paytime'      => '支付时间',
    'Createtime'   => '创建时间',
    'Updatetime'   => '更新时间',
    'Status'       => '状态',
    'Inprogress'   => '未支付',
    'Paid'         => '已支付,未通知',
    'Expired'      => '已过期',
    'Settled'      => '已完成',
    'Unsettled'    => '通知失败',
];
