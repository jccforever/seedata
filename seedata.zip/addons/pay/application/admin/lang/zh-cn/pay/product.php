<?php

return [
    'Image'      => '产品图片',
    'Price'      => '产品价格',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间',
    'Status'     => '状态'
];
