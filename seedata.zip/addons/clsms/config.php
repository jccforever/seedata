<?php

return array (
  0 => 
  array (
    'name' => 'key',
    'title' => '验证码',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => 'N166',
    'rule' => 'required',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
  1 => 
  array (
    'name' => 'secret',
    'title' => '密码',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => 'Cj1dvx',
    'rule' => 'required',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
  2 => 
  array (
    'name' => 'key1',
    'title' => '会员营销短信',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => 'CM6',
    'rule' => 'required',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
  3 => 
  array (
    'name' => 'secret1',
    'title' => '会员营销密钥',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => 'NQkxCs',
    'rule' => 'required',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
  4 => 
  array (
    'name' => 'sign',
    'title' => '短信签名',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => '【看】',
    'rule' => 'required',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
);
