<?php

return array (
  0 => 
  array (
    'name' => 'accountSid',
    'title' => '主账号Sid',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => 'aaf98f89521b91',
    'rule' => 'required',
    'msg' => '',
    'tip' => '请在https://www.yuntongxun.com/member/main中进行获取',
    'ok' => '',
    'extend' => '',
  ),
  1 => 
  array (
    'name' => 'accountToken',
    'title' => '主账号Token',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => '8f50c41e78464',
    'rule' => 'required',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
  2 => 
  array (
    'name' => 'appId',
    'title' => '应用ID',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => '8aaf070862b',
    'rule' => 'required',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
  3 => 
  array (
    'name' => 'template',
    'title' => '短信模板',
    'type' => 'array',
    'content' => 
    array (
    ),
    'value' => 
    array (
      'register' => '121649',
      'resetpwd' => '121649',
      'changepwd' => '121649',
      'profile' => '121649',
      'changemobile' => '121649',
    ),
    'rule' => 'required',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
);
