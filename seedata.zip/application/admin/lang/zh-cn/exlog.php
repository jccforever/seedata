<?php

return [
    'Uname'  =>  '用户名',
    'Content'  =>  '内容',
    'Adds'  =>  '地址',
    'Create_time'  =>  '操作时间'
];
