<?php

return [
    'Id'  =>  'ID',
    'User_id'  =>  '会员ID',
    'Ismr'  =>  '默认',
    'Ismr 0'  =>  '否',
    'Ismr 1'  =>  '是',
    'Dianpu'  =>  '旺旺',
    'Fajianren'  =>  '发件人',
    'Shouji'  =>  '手机',
    'A_province'  =>  '省',
    'City'  =>  '市',
    'Area'  =>  '区',
    'Address'  =>  '地址',
    'Statusswitch'  =>  '状态值',
    'Statusswitch 0'  =>  '禁用',
    'Statusswitch 1'  =>  '正常',
    'Create_time'  =>  '提交时间',
    'User.username'  =>  '用户名'
];
