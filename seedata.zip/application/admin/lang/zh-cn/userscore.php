<?php

return [
    'User_id'  =>  '会员ID',
    'Score'  =>  '变更积分',
    'Before'  =>  '类型',
    'Before 0'  =>  '减少',
    'Before 1'  =>  '增加',
    'After'  =>  '变更后积分',
    'Memo'  =>  '备注',
    'Createtime'  =>  '创建时间',
    'User.username'  =>  '用户名'
];
