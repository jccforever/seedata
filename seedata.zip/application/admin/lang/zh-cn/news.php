<?php

return [
    'Category_id'  =>  '新闻分类',
    'Category_id 1'  =>  '帮助说明',
    'Category_id 0'  =>  '会员公告',
    'Title'  =>  '标题',
    'Content'  =>  '新闻内容',
    'Keywords'  =>  '关键字',
    'Desc'  =>  '描述',
    'Create_time'  =>  '时间'
];
