<?php

return [
    'Name'  =>  '会员等级名称',
    'Low_price'  =>  '会员等级下线',
    'On_line'  =>  '会员等级上线',
    'Yto'  =>  '圆通',
    'Yunda'  =>  '韵达',
    'Zto'  =>  '中通',
    'Create_time'  =>  '添加时间',
    'Status'  =>  '状态',
    'Status 1'  =>  '显示',
    'Status 0'  =>  '隐藏'
];
